﻿using Antecipacao.Application.Interfaces;
using Antecipacao.Core.DTO;
using Antecipacao.Core.Entities;
using Antecipacao.Core.Extensions;
using Antecipacao.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Antecipacao.Application.Services
{
    public class EnterpriseAppService : IEnterpriseAppService
    {
        private readonly AppDbContext _context;

        public EnterpriseAppService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<EnterpriseDto>> GetAllAsync()
        {
            return await _context.Enterprises.Select(x => x.ToDto()).ToListAsync();
        }

        public async Task<EnterpriseDto?> GetByIdAsync(long id)
        {
            var result = await _context.Enterprises.FindAsync(id);
            return result.ToDto();
        }

        public async Task<EnterpriseDto> AddAsync(AddEnterpriseDto dto)
        {
            var entity = new Enterprise
            {
                CNPJ = dto.CNPJ,
                Name = dto.Name,
                MonthlyBilling = dto.MonthlyBilling,
                Branch = dto.Branch,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Enterprises.Add(entity);
            await _context.SaveChangesAsync();

            return entity.ToDto();
        }

        public async Task<bool> UpdateAsync(UpdateEnterpriseDto dto)
        {
            var entity = await _context.Enterprises.FindAsync(dto.Id);
            if (entity == null)
                return false;

            entity.CNPJ = dto.CNPJ;
            entity.Name = dto.Name;
            entity.MonthlyBilling = dto.MonthlyBilling;
            entity.Branch = dto.Branch;
            entity.UpdatedAt = DateTime.UtcNow;

            _context.Enterprises.Update(entity);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> DeleteAsync(long id)
        {
            var entity = await _context.Enterprises.FindAsync(id);
            if (entity == null)
                return false;

            _context.Enterprises.Remove(entity);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}

﻿using Antecipacao.Application.Interfaces;
using Antecipacao.Core.DTO;
using Antecipacao.Core.Entities;
using Antecipacao.Core.Extensions;
using Antecipacao.Data;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Antecipacao.Application.Services
{
    public class InvoiceAppService : IInvoiceAppService
    {
        private readonly AppDbContext _context;

        public InvoiceAppService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<InvoiceDto>> GetAllAsync()
        {
            return await _context.Invoices.Select(x => x.ToDto()).ToListAsync();
        }

        public async Task<InvoiceDto?> GetByIdAsync(long id)
        {
            var entity = await _context.Invoices.FindAsync(id);
            return entity.ToDto();
        }

        public async Task<InvoiceDto> AddAsync(AddInvoiceDto dto)
        {
            var entity = new Invoice
            {
                NfNumber = dto.NfNumber,
                Amount = dto.Amount,
                IssueDate = dto.IssueDate,
                EnterpriseId = dto.EnterpriseId,
                UpdatedAt = DateTime.UtcNow
            };

            _context.Invoices.Add(entity);
            await _context.SaveChangesAsync();

            return entity.ToDto();
        }

        public async Task<bool> UpdateAsync(UpdateInvoiceDto dto)
        {
            var entity = await _context.Invoices.FindAsync(dto.Id);
            if (entity == null)
                return false;

            entity.NfNumber = dto.NfNumber;
            entity.Amount = dto.Amount;
            entity.IssueDate = dto.IssueDate;
            entity.EnterpriseId = dto.EnterpriseId;
            entity.UpdatedAt = DateTime.UtcNow;

            _context.Invoices.Update(entity);
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> DeleteAsync(long id)
        {
            var entity = await _context.Invoices.FindAsync(id);
            if (entity == null)
                return false;

            _context.Invoices.Remove(entity);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}

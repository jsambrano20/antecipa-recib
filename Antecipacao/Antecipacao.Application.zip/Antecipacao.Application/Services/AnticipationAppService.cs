﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Antecipacao.Core.DTO.AnticipationDtos;
using Antecipacao.Core.Entities;
using Antecipacao.Data;
using Antecipacao.Core.Enums;
using System.Drawing;
using Antecipacao.Core.DTO;
using Antecipacao.Core.Extensions;
using Antecipacao.Application.Interfaces;

namespace Antecipacao.Application.Services
{
    public class AnticipationAppService : IAnticipationAppService
    {
        private readonly AppDbContext _context;

        public AnticipationAppService(AppDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<AnticipationResult?> CalculateAnticipationAsync(long enterpriseId, List<long> invoiceIds)
        {
            var enterprise = await _context.Enterprises
                .Include(e => e.Invoices)
                .FirstOrDefaultAsync(e => e.Id == enterpriseId);

            if (enterprise == null)
                return null;

            var selectedInvoices = enterprise.Invoices
                .Where(inv => invoiceIds.Contains(inv.Id))
                .ToList();

            if (!selectedInvoices.Any())
                return null;

            var creditLimit = CalculateCreditLimit(enterprise.MonthlyBilling, enterprise.Branch);
            var grossTotal = selectedInvoices.Sum(inv => inv.Amount);

            if (grossTotal > creditLimit)
                return null;

            var anticipatedInvoices = selectedInvoices.Select(inv => new AnticipatedInvoice
            {
                NfNumber = inv.NfNumber,
                GrossAmount = inv.Amount,
                NetAmount = CalculateNetValue(inv.IssueDate, inv.Amount)
            }).ToList();

            var netTotal = anticipatedInvoices.Sum(ai => ai.NetAmount);

            return new AnticipationResult
            {
                Enterprise = enterprise.Name,
                CNPJ = enterprise.CNPJ,
                Limit = creditLimit,
                Invoices = anticipatedInvoices,
                NetTotal = netTotal,
                GrossTotal = grossTotal
            };
        }

        public async Task<bool> AddInvoiceToCartAsync(long enterpriseId, long invoiceId)
        {
            var invoice = await _context.Invoices
                .FirstOrDefaultAsync(inv => inv.Id == invoiceId && inv.EnterpriseId == enterpriseId);

            if (invoice == null)
                return false;

            // Atualize o status da nota fiscal para indicar que está no carrinho
            // invoice.IsInAnticipation = true;
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<bool> RemoveInvoiceFromCartAsync(long enterpriseId, long invoiceId)
        {
            var invoice = await _context.Invoices
                .FirstOrDefaultAsync(inv => inv.Id == invoiceId && inv.EnterpriseId == enterpriseId);

            if (invoice == null)
                return false;

            // Atualize o status da nota fiscal para indicar que foi removida do carrinho
            // invoice.IsInAnticipation = false;
            await _context.SaveChangesAsync();

            return true;
        }

        public async Task<List<InvoiceDto>> GetInvoicesInCartAsync(long enterpriseId)
        {
            return await _context.Invoices
                .Where(inv => inv.EnterpriseId == enterpriseId /* && inv.IsInAnticipation */) // Descomente se usar a flag
                .Select(x=>x.ToDto())
                .ToListAsync();
        }

        private decimal CalculateCreditLimit(decimal monthlyBilling, EnumBranch branch)
        {
            if (monthlyBilling >= 10000 && monthlyBilling <= 50000)
            {
                return monthlyBilling * 0.50m;
            }
            else if (monthlyBilling >= 50001 && monthlyBilling <= 100000)
            {
                return branch == EnumBranch.Services
                    ? monthlyBilling * 0.55m
                    : monthlyBilling * 0.60m;
            }
            else if (monthlyBilling > 100000)
            {
                return branch == EnumBranch.Products
                    ? monthlyBilling * 0.60m
                    : monthlyBilling * 0.65m;
            }

            return 0;
        }

        private decimal CalculateNetValue(DateTime issueDate, decimal amount)
        {
            var daysUntilDue = (issueDate - DateTime.Now).Days;

            if (daysUntilDue <= 0)
                return 0;

            const decimal monthlyRate = 0.0465m;
            var monthsUntilDue = (decimal)daysUntilDue / 30m;

            var discountFactor = (decimal)Math.Pow((double)(1 + monthlyRate), (double)monthsUntilDue);
            var discountAmount = amount / discountFactor;

            return amount - discountAmount;
        }
    }
}

﻿using Antecipacao.Core.DTO;
using Antecipacao.Core.DTO.AnticipationDtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Antecipacao.Application.Interfaces
{
    public interface IAnticipationAppService
    {
        Task<AnticipationResult?> CalculateAnticipationAsync(long enterpriseId, List<long> invoiceIds);
        Task<bool> AddInvoiceToCartAsync(long enterpriseId, long invoiceId);
        Task<bool> RemoveInvoiceFromCartAsync(long enterpriseId, long invoiceId);
        Task<List<InvoiceDto>> GetInvoicesInCartAsync(long enterpriseId);
    }
}

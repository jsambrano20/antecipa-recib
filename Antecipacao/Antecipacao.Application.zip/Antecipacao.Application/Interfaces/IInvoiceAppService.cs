﻿using Antecipacao.Core.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Antecipacao.Application.Interfaces
{
    public interface IInvoiceAppService
    {
        Task<List<InvoiceDto>> GetAllAsync();
        Task<InvoiceDto?> GetByIdAsync(long id);
        Task<InvoiceDto> AddAsync(AddInvoiceDto dto);
        Task<bool> UpdateAsync(UpdateInvoiceDto dto);
        Task<bool> DeleteAsync(long id);
    }
}

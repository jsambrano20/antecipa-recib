﻿using Antecipacao.Core.DTO;
using Antecipacao.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Antecipacao.Application.Interfaces
{
    public interface IEnterpriseAppService
    {
        Task<List<EnterpriseDto>> GetAllAsync();
        Task<EnterpriseDto?> GetByIdAsync(long id);
        Task<EnterpriseDto> AddAsync(AddEnterpriseDto dto);
        Task<bool> UpdateAsync(UpdateEnterpriseDto dto);
        Task<bool> DeleteAsync(long id);
    }
}
